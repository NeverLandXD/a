### OPAAA ZEUS AKI GARAIO ⚡

## Ferramentas

```bash
> Termux
> WhatsApp
> 2 Celulares
```

---


- Get BarBarKey on [this site](https://mhankbarbar.tech)

---

## Instalar
Siga os passos abaixo!

```bash
> termux-setup-storage
(depois disso toque na permissão)
> apt install git
> pkg install ffmpeg
> apt install wget
> pkg install nodejs
> pkg install npm
> git clone https://github.com/vinizeus/zzeus.git
> cd zzeus
> bash install.sh
```

## Uso

```bash
> npm start
> leia o códico QR e após isso de um exit
> cd ptzeus
> npm i -g pm2
> pm2 start index.js
> pm2 monit
```


## CONTATOS

- Whatsapp: wa.me/+556993899391
- Instagram: @zultra_edits
- YouTube: https://youtube.com/channel/UCpS0ngad4LjtDoux_JvOK6Q
